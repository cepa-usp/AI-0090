// Variáveis do AI_Loader
var flashvars = {};
flashvars.ai = "AI-0090.swf";
flashvars.width = "550";
flashvars.height = "400";

// Parâmetros do player (Flash)
var params = {};
params.menu = "false";
params.scale = "noscale";

// Atributos da tag HTML que contém o SWF
var attributes = {};
attributes.id = "ai";
attributes.align = "middle";
